Vue.component('modal', {
	
	data(){
		
		return{completionRate: 50};
	}
	
	
});
new Vue({
	
	el: '#root'
	
	
	
	
});

